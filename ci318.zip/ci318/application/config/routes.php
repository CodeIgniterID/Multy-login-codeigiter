<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'm_user/login';
$route['404_override'] = 'user/page404';
$route['translate_uri_dashes'] = FALSE;
